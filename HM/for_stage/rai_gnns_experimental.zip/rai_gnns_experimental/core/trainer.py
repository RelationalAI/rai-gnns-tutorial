import uuid
from typing import Optional

import requests

from rai_gnns_experimental.common.dataset_model import EvaluationMetric
from rai_gnns_experimental.common.export import OutputConfig
from rai_gnns_experimental.common.job_models import JobTypes, PayloadTypes
from src.utils.logger import SafeLogger

from .config_trainer import TrainerConfig
from .connector import BaseConnector
from .dataset import Dataset
from .job_manager import JobMonitor
from .utils import extract_error_message

safe_logger = SafeLogger()


class Trainer:
    def __init__(self, connector: BaseConnector, config: TrainerConfig):
        """
        Trainer class for the GNN-RLE.

        Initializes and manages the training process for a GNN model.

        :param connector: Connector object used to interact with the data source.
        :type connector: Connector
        :param config: Configuration object containing all training hyperparameters.
        :type config: TrainerConfig
        """

        self.connector = connector
        self.config = config.to_dict()
        self.router_url = f"{connector.endpoint_url}/v1alpha1/jobs/create"

    def _parse_request_exception(self, response):
        """Extracts and formats error message from a failed requests response."""
        try:
            error_detail = response.json().get("detail", "No detail provided")
            return f"❌ Error: {error_detail}"
        except (ValueError, AttributeError):
            return "❌ Error: Failed to parse error response"

    def _make_api_request(self, payload: dict) -> dict:
        """Make an API request with the given payload to the router.
        Args:
            payload: The JSON payload to send with the request

        Returns:
            dict: The JSON response from the API
        """
        try:
            if not self.connector.is_native_app:
                job_id = str(uuid.uuid4())
                url = f"{self.router_url}/{job_id}"

                response = requests.post(url, json=payload, headers=self.connector.headers, timeout=60)
                response.raise_for_status()
                return response.json().get("data", {})

            # SQL stored procedure approach
            return self.connector.exec_job(payload)

        except requests.RequestException:
            error_message = self._parse_request_exception(response)
            print(error_message)
            return None

        except Exception as e:
            err_msg = extract_error_message(str(e))
            safe_logger.error("❌ %s", err_msg)
            return None

    def _add_inference_export_config(self, **model_params):
        """Get dataset metadata from MLflow artifacts."""

        payload = {
            "payload_type": PayloadTypes.ADD_INFERENCE_EXPORT,
            "config": self.config,
            **{k: v for k, v in model_params.items() if v is not None},
        }
        return self._make_api_request(payload)

    def _submit_job(self, dataset_metadata: dict, job_type: JobTypes) -> JobMonitor:
        """
        Helper method to submit a job request to the remote training system.

        Args:
            dataset_metadata (dict): The dataset metadata for training/inference.
            job_type (JobTypes): The type of job - "train", "inference", or "both".

        Returns:
            JobMonitor: An object representing the submitted job.
        """
        payload = {
            "payload_type": PayloadTypes.JOB,
            "dataset_metadata": dataset_metadata,
            "model_configuration": self.config,
            "job_type": job_type,
        }
        job_data = self._make_api_request(payload)

        if self.connector.is_native_app:
            payload_logs = {
                "payload_type": PayloadTypes.SEND_LOGS,
                "job_id": job_data["job_id"],
                "stream_name": "progress",
            }

            _ = self._make_api_request(payload_logs)

        if job_data:
            job_monitor = JobMonitor(connector=self.connector, job_id=job_data["job_id"], job_type=job_type)
            return job_monitor

    def _get_dataset_metadata(self, experiment_name, **params):
        """Get dataset metadata from MLflow artifacts."""
        payload = {
            "payload_type": PayloadTypes.REQUEST_DATASET_CONFIG,
            "experiment_name": experiment_name,
            **{k: v for k, v in params.items() if v is not None},
        }
        return self._make_api_request(payload)

    def fit(self, dataset: Dataset) -> JobMonitor:
        """
        Submit a training job.

        :param dataset: The dataset to be used for training.
        :type dataset: Dataset
        :returns: An object to monitor the submitted job, check its status, track model progress, and retrieve metrics
            after training.
        :rtype: JobMonitor
        """
        return self._submit_job(dataset_metadata=dataset.metadata_dict, job_type=JobTypes.TRAIN)

    def predict(
        self,
        output_alias: str,
        output_config: OutputConfig = None,
        test_batch_size: int = 128,
        experiment_name: Optional[str] = None,
        dataset: Optional[Dataset] = None,
        test_table: Optional[str] = None,
        select_best_model: Optional[bool] = False,
        model_run_id: Optional[str] = None,
        registered_model_name: Optional[str] = None,
        version: Optional[str] = None,
        evaluation_metric: Optional[EvaluationMetric] = None,
        extract_embeddings: bool = False,
    ) -> JobMonitor:
        """
        Submits an inference job.

        Either a dataset or an experiment name must be provided. If `experiment_name` is specified, the dataset
        used in that experiment will be reused, avoiding the need to redefine it.

        Inference logic:

        1. One of `dataset` or `experiment_name` must be provided.
        - If `experiment_name` is provided, the dataset used in that experiment will be reused.

        2. A model must be selected using one of the following options:
        a. `registered_model_name` + `version`: Use a specific registered model from MLflow.
        b. `select_best_model=True` + `evaluation_metric`: Automatically select the best model for the experiment.
            If `dataset` is provided, `evaluation_metric` is optional and can be inferred from metadata.
        c. `model_run_id`: Use a specific model run ID.

        3. The `test_table` argument is only valid when `experiment_name` is provided.

        :param output_config: Configuration specifying where to save results.
                            Use `OutputConfig.local()` or `OutputConfig.snowflake()`.
        :type output_config: OutputConfig

        :param output_alias: An alias to append to the result tables of predictions and embeddings.
        :type output_alias: str

        :param test_batch_size: Test batch size to use during inference. Defaults to 128.
        :type test_batch_size: int, optional

        :param experiment_name: Name of the experiment to run inference for.
        :type experiment_name: str, optional

        :param dataset: Dataset to run inference on. Required if `experiment_name` is not provided.
        :type dataset: Dataset, optional

        :param test_table: Fully qualified test table path. Required only when using `experiment_name`.
        :type test_table: str, optional

        :param registered_model_name: Name of the registered model in MLflow.
        :type registered_model_name: str, optional

        :param version: Version of the registered model.
        :type version: str, optional

        :param select_best_model: If True, select the best model based on the evaluation metric.
        :type select_best_model: bool, optional

        :param evaluation_metric: Metric used to select the best model.
        :type evaluation_metric: str, optional

        :param model_run_id: Run inference using this specific model run ID.
        :type model_run_id: str, optional

        :param extract_embeddings: If True, extract node embeddings.
        :type extract_embeddings: bool, optional

        :returns: An object representing the submitted job, which can be used to monitor job status, retrieve metrics,
                and track progress.
        :rtype: JobMonitor
        """

        # Step 1: Validate input requirements
        if select_best_model is False and evaluation_metric is not None:
            safe_logger.error("❌ Error: Evaluation_metric can only be provided when select_best_model is set to True.")
            return None

        if registered_model_name is None and version is not None:
            safe_logger.error("❌ Error: Version can only be provided when a registered model is provided.")
            return None

        if registered_model_name is not None and select_best_model is True:
            safe_logger.error("❌ Error: You can either use a registered model or select the best model, not both.")
            return None

        if model_run_id is not None and select_best_model is True:
            safe_logger.error(
                "❌ Error: You can either use a model based on its run_id or select the best model, not both."
            )
            return None

        if model_run_id is not None and registered_model_name is not None:
            safe_logger.error(
                "❌ Error: You can either use a model based on its run_id or a registered model, not both."
            )
            return None

        # Either dataset or experiment_name must be provided
        if not dataset and not experiment_name:
            safe_logger.error("❌ Error: Both dataset and experiment_name are missing. One must be provided.")
            return None

        if registered_model_name is not None:
            model_selection_strategy = "registered"
        elif select_best_model:
            model_selection_strategy = "best"
            if evaluation_metric is not None:
                evaluation_eval_at_k = evaluation_metric.eval_at_k
                evaluation_metric = evaluation_metric.name
        else:
            model_selection_strategy = "current"

        # Step 2: Obtain dataset metadata
        # - If dataset object is provided, use its metadata directly
        # - Otherwise, retrieve metadata from MLflow
        if not dataset:
            if not test_table:
                safe_logger.error("❌ Error: Test table is mandatory when using an experiment name.")
                return None

            metadata_dict = self._get_dataset_metadata(
                experiment_name=experiment_name,
                model_run_id=model_run_id,
                model_selection_strategy=model_selection_strategy,
                registered_model_name=registered_model_name,
                version=version,
                evaluation_metric=evaluation_metric,
            )
            if not metadata_dict:
                return None
            metadata_dict["connector"]["experiment_name"] = experiment_name

        else:
            metadata_dict = dataset.metadata_dict
            extracted_exp_name = dataset.experiment_name
            if evaluation_metric is None:
                evaluation_eval_at_k = metadata_dict["task"]["evaluation_metric"].get("eval_at_k")
                evaluation_metric = metadata_dict["task"]["evaluation_metric"]["name"]

            # Fetch metadata using the extracted experiment name for validation
            model_metadata_dict = self._get_dataset_metadata(
                experiment_name=extracted_exp_name,
                model_run_id=model_run_id,
                model_selection_strategy=model_selection_strategy,
                registered_model_name=registered_model_name,
                version=version,
                evaluation_metric=evaluation_metric,
            )
            if not model_metadata_dict:
                return None

        if not metadata_dict:
            return None

        # Step 3: Configure inference and export parameters
        # Configure inference and export parameters
        if output_config.type == "snowflake":
            snowflake_settings = output_config.settings
            self.config = self._add_inference_export_config(
                test_batch_size=test_batch_size,
                model_selection_strategy=model_selection_strategy,
                model_run_id=model_run_id,
                registered_model_name=registered_model_name,
                version=version,
                extract_embeddings=extract_embeddings,
                output_alias=output_alias,
                database_name=snowflake_settings.database_name,
                schema_name=snowflake_settings.schema_name,
            )
        elif output_config.type == "local":
            local_settings = output_config.settings
            self.config = self._add_inference_export_config(
                test_batch_size=test_batch_size,
                model_selection_strategy=model_selection_strategy,
                model_run_id=model_run_id,
                registered_model_name=registered_model_name,
                version=version,
                extract_embeddings=extract_embeddings,
                output_alias=output_alias,
                artifacts_dir=local_settings.artifacts_dir,
                extension=local_settings.extension,
            )
        if not self.config:
            return None

        # Step 4: Apply optional overrides to metadata
        if evaluation_metric:
            metadata_dict["task"]["evaluation_metric"]["name"] = evaluation_metric
            metadata_dict["task"]["evaluation_metric"]["eval_at_k"] = evaluation_eval_at_k

        if test_table is not None and experiment_name is not None:
            metadata_dict["task"]["source"]["test"] = test_table

        if not metadata_dict.get("task", {}).get("source", {}).get("test"):
            safe_logger.error("❌ Error: Dataset metadata is missing a test table.")
            return None

        # Step 5: Submit the inference job and return a monitor to track progress
        return self._submit_job(dataset_metadata=metadata_dict, job_type=JobTypes.INFERENCE)

    def fit_predict(
        self,
        dataset: Dataset,
        output_alias: str,
        output_config: OutputConfig = None,
        test_batch_size: int = 128,
        extract_embeddings: bool = False,
    ) -> JobMonitor:
        """
        Submits a job that performs both training and inference.

        This function trains a GNN model using the provided dataset and then runs inference on the test data. The
        dataset must include a test table.

        :param dataset: The dataset to be used for training and inference. Must include a test table.
        :type dataset: Dataset
        :param output_config: Configuration specifying where to save results. Use `OutputConfig.local()` or
            `OutputConfig.snowflake()`.
        :type output_config: OutputConfig
        :param output_alias: An alias to append to the result tables for predictions and embeddings.
        :type output_alias: str
        :param test_batch_size: Test batch size to use during inference. Defaults to 128.
        :type test_batch_size: int, optional
        :param extract_embeddings: Set to True to extract node embeddings.
        :type extract_embeddings: bool
        :returns: An object representing the submitted job. This object can be used to check job status, retrieve
            training metrics, and monitor progress.
        :rtype: JobMonitor :example: # Snowflake output trainer.fit_predict( dataset=dataset,
            output_config=OutputConfig.snowflake( database_name="SYNTHETIC_ACADEMIC_RANKING_DB", schema_name="PUBLIC" ),
            output_alias="my_predictions" )
        """

        test_table = dataset.metadata_dict.get("task", {}).get("source", {}).get("test")
        if not test_table:
            safe_logger.error("❌ Error: Dataset metadata is missing a test table.")
            return None

        # Configure inference and export parameters
        if output_config.type == "snowflake":
            snowflake_settings = output_config.settings
            self.config = self._add_inference_export_config(
                test_batch_size=test_batch_size,
                model_selection_strategy="current",
                model_run_id=None,
                registered_model_name=None,
                version=None,
                extract_embeddings=extract_embeddings,
                output_alias=output_alias,
                database_name=snowflake_settings.database_name,
                schema_name=snowflake_settings.schema_name,
            )
        elif output_config.type == "local":
            local_settings = output_config.settings
            self.config = self._add_inference_export_config(
                test_batch_size=test_batch_size,
                model_selection_strategy="current",
                model_run_id=None,
                registered_model_name=None,
                version=None,
                extract_embeddings=extract_embeddings,
                output_alias=output_alias,
                artifacts_dir=local_settings.artifacts_dir,
                extension=local_settings.extension,
            )
        if not self.config:
            return None

        return self._submit_job(dataset_metadata=dataset.metadata_dict, job_type=JobTypes.TRAIN_INFERENCE)
